// Architecture design document (RFC) in Markdown, assembled from the document, the model
// and the analysis results. Every modelled figure is labelled as such, and assumed inputs
// are marked with an asterisk.

import { simulate } from '../sim.mjs';
import { review } from '../review.mjs';
import { buildFmea } from '../fmea.mjs';
import { estimateCost } from '../cost.mjs';
import { buildScenarios, runScenario } from '../scenarios.mjs';
import { formatCost, formatUsd, formatPrice, formatQuantity, costLines, simulationHeadline, reviewHeadline, noFindingsText, statusLabel } from '../present.mjs';
import { toMermaidFlowchart } from './mermaid.mjs';
import { mdLineStart, mdTable, mdText, plural, preformatted } from './shared.mjs';

// The asterisk is the exporter's own mark, so the cell is written as Markdown here.
const mark = (node, key, value) => (value == null ? 'not set' : preformatted(`${mdText(value)}${node.basis[key] === 'assumed' ? '*' : ''}`));
const seconds = (value) => (value == null ? 'not set' : `${value} s`);

export function toRfc(document, model) {
  const result = simulate(model);
  const findings = review(model);
  const fmea = buildFmea(model);
  const cost = estimateCost(model, result);
  const scenarios = buildScenarios(model).map((scenario) => ({ scenario, outcome: runScenario(model, scenario) }));
  const name = (id) => model.display?.[id] ?? model.nodes.find((n) => n.id === id)?.label ?? id;
  const costHead = formatCost(cost);
  const status = (key) => statusLabel(result.assessments[key].status);
  const k = result.kpis;
  const out = [];
  const push = (...lines) => out.push(...lines);

  push(`# ${mdText(model.title)}: architecture design`, '');
  push('> Generated from an Archi-Made-Easy architecture document. Figures under "Modelled behaviour", "Review", "Failure modes" and "Scenarios" come from an analytical model of the declared design. They are not measurements. Values marked with an asterisk (*) were assumed from the component\'s role because the document does not state them.', '');

  push('## 1. Summary', '');
  push(`- ${plural(model.nodes.filter((n) => !n.actor).length, 'component')}, ${plural(model.edges.length, 'connection')}, ${plural(model.boundaries.length, 'boundary')}.`);
  push(`- Entry points: ${model.entrypoints.map((id) => mdText(name(id))).join(', ') || 'none identified'}.`);
  push(`- Review: ${mdText(reviewHeadline(findings).text.replace(/^Score: /, ''))}, with ${findings.findings.length} finding${findings.findings.length === 1 ? '' : 's'} and ${findings.gaps.length} check${findings.gaps.length === 1 ? '' : 's'} that could not be evaluated.`);
  push(`- Model status: ${statusLabel(result.status)}. Cost estimate: ${statusLabel(cost.status)}.`);
  push(`- Inputs: ${result.basis.authored_inputs} authored, ${result.basis.assumed_inputs} assumed. Evidence confidence: ${result.confidence.level}.`, '');

  const assumptions = (document.cards || []).find((card) => card.title === 'Assumptions');
  if (assumptions || model.requirements) {
    push('## 2. Requirements and assumptions', '');
    if (model.requirements) {
      const r = model.requirements;
      const rows = [
        ['Availability target', r.availability_target_percent != null ? `${r.availability_target_percent}%` : null],
        ['P99 latency target', r.p99_latency_ms != null ? `${r.p99_latency_ms} ms` : null],
        ['Peak load', r.peak_rps != null ? `${r.peak_rps} requests/s` : null],
        ['Users', r.users], ['RPO', r.rpo_sec != null ? `${r.rpo_sec} s` : null], ['RTO', r.rto_sec != null ? `${r.rto_sec} s` : null],
        ['Monthly budget', r.monthly_budget_usd != null ? `$${r.monthly_budget_usd}` : null],
        ['Regions', r.regions?.join(', ')], ['Data residency', r.data_residency?.join(', ')], ['Compliance', r.compliance?.join(', ')],
      ].filter(([, value]) => value != null && value !== '');
      if (rows.length) push(mdTable(['Requirement', 'Target'], rows), '');
    }
    if (assumptions) push('Assumptions:', '', ...assumptions.items.map((item) => `- ${mdLineStart(mdText(item))}`), '');
  }

  push('## 3. Architecture', '', '```mermaid', toMermaidFlowchart(model), '```', '');
  push('### Components', '');
  push(mdTable(['Component', 'Role', 'Redundancy', 'Unit SLA %', 'Capacity (requests/s)', 'P99 (ms)', 'Trust zone'],
    model.nodes.filter((n) => !n.actor).map((n) => [
      n.label, mark(n, 'role', n.role), mark(n, 'redundancy', n.redundancy), mark(n, 'sla_percent', n.sla_percent),
      n.capacity.max_rps == null ? 'not set' : preformatted(`${n.capacity.max_rps * (n.capacity.autoscale_max ?? 1)}${n.basis['capacity.max_rps'] === 'assumed' ? '*' : ''}`),
      mark(n, 'latency.p99_ms', n.latency.p99_ms), n.security.trust_zone ?? '',
    ])), '');
  push('### Connections', '');
  push(mdTable(['From', 'To', 'Purpose', 'Semantics', 'Protocol', 'Resilience'],
    [...model.edges].sort((a, b) => (a.id < b.id ? -1 : 1)).map((e) => [
      name(e.from), name(e.to), e.label ?? '', preformatted(`${e.call_semantics}${e.basis.call_semantics === 'assumed' ? '*' : ''}`), e.protocol ?? '',
      [e.resilience.timeout_ms != null ? `timeout ${e.resilience.timeout_ms} ms` : null, e.resilience.retries ? `${e.resilience.retries} retries` : null,
        e.resilience.circuit_breaker_enabled ? 'circuit breaker' : null, e.resilience.fallback_edge_id ? `fallback ${e.resilience.fallback_edge_id}` : null,
        e.resilience.dlq_node_id ? `dead letters to ${name(e.resilience.dlq_node_id)}` : null, e.resilience.idempotent ? 'idempotent' : null].filter(Boolean).join(', '),
    ])), '');

  push('## 4. Modelled behaviour', '');
  push(mdTable(['Measure', 'Modelled value', 'Status'], [
    ['Composite availability (requests answered, including degraded answers)', k.composite_sla_percent == null ? 'not available' : `${k.composite_sla_percent}%`, status('availability')],
    ['Critical path', k.critical_path ? k.critical_path.nodes.map(name).join(' → ') : 'none', status('latency')],
    ['Critical-path latency', k.critical_path?.p99_ms != null ? `P50 ${k.critical_path.p50_ms} ms, P95 ${k.critical_path.p95_ms} ms, P99 ${k.critical_path.p99_ms} ms` : 'not available', status('latency')],
    ['Capacity ceiling of the request path', k.max_sustainable_rps == null ? 'not available' : `${k.max_sustainable_rps} requests/s (limit: ${name(k.limiting_node)})`, status('capacity')],
    ['Asynchronous drain ceiling', k.async_drain_ceiling_rps == null ? 'not applicable' : `${k.async_drain_ceiling_rps} requests/s (limit: ${name(k.async_limiting_node)}); above it a backlog grows`, status('capacity')],
    ['Current ingress', k.ingress_rps == null ? 'not stated' : `${k.ingress_rps} requests/s (headroom ${k.headroom}x)`, status('traffic')],
    ['Single points of failure', k.active_spofs.length ? k.active_spofs.map(name).join(', ') : 'none found', status('structure')],
    [`Monthly cost: ${costHead.label.toLowerCase()}`, `${costHead.text} (${costHead.coverage})`, statusLabel(cost.status)],
  ]), '');
  for (const item of result.reasons) push(`- Note (${item.code}): ${mdText(item.message)}`);
  if (result.reasons.length) push('');

  push('### Cost estimate', '');
  push(`${costHead.label}: **${mdText(costHead.text)}** ${mdText(costHead.qualifier)}. ${mdText(costHead.coverage)}.`, '');
  const meterRows = model.nodes.filter((n) => cost.nodes[n.id]?.priced).flatMap((n) => cost.nodes[n.id].meters.map((meter) => [
    name(n.id), meter.dimension, meter.quantity == null ? 'not known' : formatQuantity(meter.quantity, meter.unit),
    meter.tiers ? 'tiered' : `${formatPrice(meter.price)} per ${meter.per === 1 ? meter.unit : formatQuantity(meter.per, meter.unit)}`,
    meter.cost_usd == null ? `left out (${statusLabel(meter.status)})` : formatUsd(meter.cost_usd),
    meter.source ? [meter.source.provider, meter.source.service, meter.source.region, meter.source.retrieved_at ? `retrieved ${meter.source.retrieved_at}` : null].filter(Boolean).join(', ') : 'no source',
  ]));
  if (meterRows.length) push(mdTable(['Component', 'Billed dimension', 'Monthly quantity', 'Price', 'Cost', 'Price source'], meterRows), '');
  for (const line of costLines(cost, name)) push(`- ${mdText(line)}`);
  push('');

  push('## 5. Review', '');
  push(mdText(reviewHeadline(findings).text), '');
  push(mdTable(['Pillar', 'Score', 'Lowest possible', 'Rules evaluated', 'Status', 'Findings'], Object.entries(findings.pillars).map(([pillar, value]) => [
    pillar, value.score == null ? 'not assessed' : value.score, value.floor == null ? 'not assessed' : value.floor,
    `${value.rules.evaluated} of ${value.rules.applicable}`, statusLabel(value.status), value.findings])), '');
  if (findings.findings.length) {
    push(mdTable(['Severity', 'Finding', 'Evidence', 'Remediation', 'Basis'], findings.findings.map((f) => [f.severity, f.title, f.evidence, f.remediation, f.basis])), '');
  } else push(noFindingsText(findings), '');
  if (findings.gaps.length) {
    push('### Not evaluated', '', 'These checks apply to the design but could not be run. They are not passes.', '');
    push(mdTable(['Check', 'Pillar', 'Why it was not evaluated', 'What to supply'], findings.gaps.map((gap) => [gap.title, gap.pillar, gap.message, gap.ask ?? ''])), '');
  }

  push('## 6. Failure modes', '');
  push(mdTable(['Component', 'Effect', 'Also affected', 'Ingress lost', 'Severity', 'RTO', 'RPO', 'Recommended'],
    fmea.rows.map((row) => [row.label, row.local_effect, row.affected_components.map(name).join(', ') || 'none',
      row.ingress_share_lost == null ? 'n/a' : `${Math.round(row.ingress_share_lost * 100)}%`, row.severity, seconds(row.recovery.rto_sec), seconds(row.recovery.rpo_sec), row.recommended_actions.join('; ')])), '');
  push(fmea.note, '');

  push('## 7. Scenarios', '');
  push(mdTable(['Scenario', 'What fails', 'Status', 'Outcome'], scenarios.map(({ scenario, outcome }) => {
    if (!outcome.applicable) return [scenario.title, 'n/a', 'not applicable', `Not applicable: ${outcome.reason}`];
    const r = outcome.result;
    // The outcome sentence is the canonical headline: the same words as every other output.
    const head = simulationHeadline(model, r);
    const failing = r.kpis.blast_radius.nodes.filter((id) => r.nodes[id].state === 'failing').map(name);
    const degraded = r.kpis.blast_radius.nodes.filter((id) => r.nodes[id].state === 'degraded').map(name);
    const detail = head.status === 'inconclusive' ? [] : [failing.length ? `failing: ${failing.join(', ')}` : null, degraded.length ? `degraded: ${degraded.join(', ')}` : null];
    const parts = [head.text, ...head.lines, ...detail,
      outcome.analysis ? `reachable without authentication: ${outcome.analysis.reachable_without_authentication.map(name).join(', ') || 'nothing'}` : null].filter(Boolean);
    return [scenario.title, scenario.fails ?? scenario.target_labels.join(', '), statusLabel(head.status), parts.join(' ')];
  })), '');

  if (model.adrs.length) {
    push('## 8. Decisions', '');
    for (const adr of model.adrs) {
      push(`### ${mdText(adr.title)}`, '', `Status: ${adr.status}`, '');
      if (adr.context) push(`**Context.** ${mdText(adr.context)}`, '');
      push(`**Decision.** ${mdText(adr.decision)}`, '');
      if (adr.alternatives?.length) push(mdTable(['Alternative', 'For', 'Against'], adr.alternatives.map((a) => [a.option, (a.pros || []).join('; '), (a.cons || []).join('; ')])), '');
      if (adr.consequences) push(`**Consequences.** ${mdText(adr.consequences)}`, '');
    }
  }

  push('## Appendix: how to read this document', '');
  push('- An asterisk (*) marks a value assumed from the component\'s role. Replace it with a real figure and regenerate.');
  push('- The model is steady-state and treats failures as independent. It ranks risks and shows propagation; it does not replace load or failover testing.');
  push(`- Review rules: ${findings.rules_checked.length}, of which ${findings.coverage.applicable} apply to this design and ${findings.coverage.evaluated} were fully evaluated. The score summarises the rules that ran; the lowest possible score assumes every rule that could not run had fired.`);
  push('- A status of partial means a figure is a subset or a lower bound; inconclusive means an essential input is missing and no conclusion is drawn; unknown means there was nothing to evaluate. None of these is a pass.');
  push('- A cost total is given only when every priceable component is priced on every dimension its pricing model bills. Otherwise the figure is a partial subtotal.', '');
  return out.join('\n');
}
