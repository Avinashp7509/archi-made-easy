// Re-render every bundled example from its JSON IR. Installed skills keep HTML
// beside the JSON examples; the development script passes the golden directory.

import { execFileSync } from 'node:child_process';
import path from 'node:path';
import { fileURLToPath } from 'node:url';

const __dirname = path.dirname(fileURLToPath(import.meta.url));
const skillRoot = path.resolve(__dirname, '..');
const outputRoot = path.resolve(process.argv[2] || path.join(skillRoot, 'examples'));

const TARGETS = [
  ['workflow', 'agent-tool-call.workflow.json', 'workflow-agent-tool-call-rendered.html'],
  ['sequence', 'cache-miss-request.sequence.json', 'sequence-cache-miss-request.html'],
  ['dataflow', 'product-analytics.dataflow.json', 'dataflow-product-analytics.html'],
  ['lifecycle', 'agent-run.lifecycle.json', 'lifecycle-agent-run.html'],
  ['architecture', 'web-app.architecture.json', 'web-app-rendered.html'],
  ['architecture', 'global-fintech-payment-mesh.architecture.json', 'global-fintech-payment-mesh.html'],
  ['architecture', 'enterprise-agentic-ai-platform.architecture.json', 'enterprise-agentic-ai-platform.html'],
  ['architecture', 'cloud-native-ecommerce-c4.architecture.json', 'cloud-native-ecommerce-c4.html'],
  ['erd', 'orders.erd.json', 'erd-orders-rendered.html'],
  ['erd', 'subscription-billing.erd.json', 'subscription-billing-rendered.html'],
  ['tree', 'payment-platform.tree.json', 'tree-payment-platform-rendered.html'],
  ['tree', 'project-repository.tree.json', 'tree-project-repository-rendered.html'],
  ['class', 'payments.class.json', 'class-payments-rendered.html'],
  ['class', 'payment-processors.class.json', 'class-payment-processors-rendered.html'],
  ['timeline', 'payment-incident.timeline.json', 'timeline-payment-incident-rendered.html'],
  ['timeline', 'project-dev-activity.timeline.json', 'timeline-project-dev-activity-rendered.html'],
  ['waterfall', 'checkout-request.waterfall.json', 'waterfall-checkout-request-rendered.html'],
  ['waterfall', 'example-rebuild.waterfall.json', 'waterfall-example-rebuild-rendered.html'],
];

for (const [mode, input, output] of TARGETS) {
  execFileSync(process.execPath, [
    path.join(skillRoot, `renderers/${mode}/render-${mode}.mjs`),
    path.join(skillRoot, 'examples', input),
    path.join(outputRoot, output),
  ], { stdio: 'inherit' });
}
